from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from PIL import Image
root=Path(__file__).resolve().parent
dist=root/'brand'
out=root/'Wetland_Donor_Booth_One_Pager_Branded.pdf'
for n,f in [('Noto','regular'),('NotoBold','bold'),('NotoBlack','black')]:
    pdfmetrics.registerFont(TTFont(n,str(dist/f'fonts/noto-sans-{f}.ttf')))
C={'blue':'#006BD9','ink':'#151435','lime':'#D6FF00','cream':'#F8F0E4','white':'#FFFFFF','muted':'#44435D'}
c=canvas.Canvas(str(out),pagesize=(612,792))
c.setTitle('Wetland | More time for people. More focus on impact.')
c.setAuthor('Wetland hackathon team')
def box(x,y,w,h,col):
    c.setFillColor(HexColor(C[col])); c.rect(x,792-y-h,w,h,fill=1,stroke=0)
def text(s,x,y,w,size=10,font='Noto',color='ink',leading=None):
    p=Paragraph(s,ParagraphStyle('p',fontName=font,fontSize=size,leading=leading or size*1.4,textColor=HexColor(C[color])))
    _,h=p.wrap(w,792);p.drawOn(c,x,792-y-h);return h
def img(name,x,y,w):
    path=dist/'assets/png'/name
    with Image.open(path) as im: h=w*im.height/im.width
    c.drawImage(str(path),x,792-y-h,width=w,height=h,mask='auto')
box(0,0,612,792,'white')
box(0,0,612,256,'blue')
img('wateraid-white-logo-1280.png',36,26,132)
text('WETLAND / HACKATHON CONCEPT',317,36,260,9,'NotoBold','white')
text('More time for people.',36,92,540,29,'NotoBlack','white',36)
text('More focus on impact.',36,129,540,29,'NotoBlack','lime',36)
text('A practical plan for responsible AI that helps charity teams focus on lasting water, sanitation and hygiene.',36,190,525,11,'Noto','white',16)
# Official thematic artwork as a WASH strip, separate from the three proposed benefits.
box(36,273,540,43,'cream')
for x,name,label in [(48,'wateraid-tap-128.png','Water'),(220,'wateraid-toilet-128.png','Sanitation'),(410,'wateraid-hygiene-128.png','Hygiene')]:
    img(name,x,282,23);text(label,x+34,285,110,10,'NotoBold')
text('A clearer path from your support to lasting change',36,334,540,15,'NotoBlack',leading=20)
text('We are designing a dashboard that shows where AI could help, what it would cost, who is accountable and how success would be measured. It gives donors a clear view of the plan before expansion.',36,363,540,10,leading=14)
rows=[('01','Stronger donor relationships','Help teams answer routine enquiries sooner, prepare relevant updates and spend more time on meaningful conversations.'),('02','Clearer evidence of progress','Help staff assemble source-linked reports and flag conflicting information for review before it reaches supporters.'),('03','Earlier insight for local teams','Help programme teams spot service issues in monitoring data, with local people deciding what action to take.')]
for i,(n,title,body) in enumerate(rows):
    y=422+i*62
    box(36,y+2,31,29,'cream');text(n,42,y+7,25,12,'NotoBlack','blue')
    text(title,80,y,496,12,'NotoBold',leading=16)
    text(body,80,y+21,496,9.8,leading=14)
box(36,614,540,66,'cream')
text('People lead. Evidence matters.',50,624,512,13,'NotoBlack')
text('Start small, protect data and train staff. Review accuracy, workload and costs before expanding. People remain accountable for decisions.',50,646,512,9.5,leading=13)
box(36,695,540,49,'lime')
text('Help shape what comes next.',50,702,512,15,'NotoBlack')
text('Visit our booth. Explore the dashboard concept. Discuss a pilot partnership.',50,725,512,9,'NotoBold',leading=12)
text('Independent Wetland hackathon concept, not an official WaterAid programme. Proposed benefits are not measured results. Demonstration uses fictional Water Care Canada case data.',36,755,540,7,'Noto','muted',10)
c.showPage();c.save()
print(out)
